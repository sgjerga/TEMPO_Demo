n.v=length(ovars)
ovars.long=c("MADRS","SIB-8",paste("Neuropsychiatric Inventory (NPI) - ",c("Symptom severity","Caregiver distress")),"EQ-VAS","QOL-AD","PCTB")
tvec=c(0,3,6,12)
xst=c(4,7)

# Create result tables
# head 
lm.head0=matrix(ncol = 9,nrow = 3)
lm.head0[2,xst]=c("Marginal estimates","ANCOVA")
lm.head0[3,c(3,xst[1]+(0:1),xst[2]+(0:2))]=c("N","Mean (CI)","Mean difference (CI)","B (CI)","p-value","Cohen's d (CI)")
lm.head0[3,1]="Groups"

# body
lm.body0=matrix(ncol = 9,nrow = 8)
lm.body0[,1]=c("SC","only RCS","only GMT","RCS and GMT","all RCS1","all GMT2","Interaction RCS*GMT",
               "1 all RCS: only RCS + RCS and GMT (vs. only GMT + SC). 2 all GMT: only GMT + RCS and GMT  (vs. only RCS + SC)")

# Computation of the models
tab.lm=numeric()
tab.lm.list=list()
for(j in 1:7){  # country
  # select data set
  if(j==1){
    dtmp1=df.resident.wide
    dtmp2=df.staff.wide
  }else{
    dtmp1=df.resident.wide[df.resident.wide$country==levels(df.resident.wide$country)[j-1],]
    dtmp2=df.staff.wide[df.staff.wide$country==levels(df.staff.wide$country)[j-1],]
  }
  if(test.ppa){
    dtmp1=dtmp1[dtmp1$pp==levels(dtmp1$pp)[1],]
  }
  # Reset results table
  tab.lm=numeric()
  
  for(i in 1:(n.v-as.numeric(test.ppa))){   # outcome variable
    if(!(((i==7)&(j==n.v))|((j==5)&(i==5)))){ # Exclude models with data damage
    ovar = ovars[i]
    writeLines(ovars.long[i])
    # Preparation of table
    tab.lm0=numeric()
    lm.head=lm.head0
    lm.body=lm.body0
    if(test.ppa){
      ppatxt="PPA"
    }else{
      ppatxt="ITT"
    }
    if(j==1){
      lm.head[1,1]=paste0("All countries: ",ovars.long[i]," (",ppatxt,")")
      writeLines("All countries")
    }else{
      lm.head[1,1]=paste0(levels(df.resident.wide$country)[j-1],": ",ovars.long[i]," (",ppatxt,")")
      writeLines(levels(df.resident.wide$country)[j-1])
    }
    
    # Select data (residents/staff)
    if(i<n.v){
      dtmp=dtmp1
    }else{
      dtmp=dtmp2
    }
    if(sum(!is.na(dtmp[,paste0(ovar,".6")]))>0){     # check missing data
      # Compute the model
      fmla = as.formula(paste0(ovar,".6 ~ rand.rcs*rand.gmt + ",ovar,".0"))
      if(j==1){
        lm.0 = lme(fmla, random = ~1|rv, na.action="na.omit", data=dtmp, method = "REML")
      }else{
        lm.0 = lme(fmla, random = ~1|rv2, na.action="na.omit", data=dtmp, method = "REML")
      }

      # Compute and add marginal estimates
      mp=emmeans(lm.0, ~ rand.rcs*rand.gmt)
      mci=summary(mp)

      # Add model estimations to the table
      t0=summary(lm.0)$tTable
      ci=intervals(lm.0, which = "fixed")$fixed
      cd=t_to_d(t=t0[,4], df_error = t0[,3])
      for(i2 in 2:4){
        lm.body[3+i2,xst[2]]=paste0(round(ci[i2+(i2==4),2],1), " (",round(ci[i2+(i2==4),1],1), ", ",round(ci[i2+(i2==4),3],1), ")")
        if(t0[i2+(i2==4),5]<0.001){
          lm.body[3+i2,xst[2]+1]="<0.0001"
        }else{
          lm.body[3+i2,xst[2]+1]=round(t0[i2+(i2==4),5],4)
        }
        lm.body[3+i2,xst[2]+2]=paste0(round(cd[i2+(i2==4),1],1), " (",round(cd[i2+(i2==4),3],1), ", ",round(cd[i2+(i2==4),4],1), ")")
      }
      lm.body[1:4,xst[2]+(0:2)]="-"
      lm.body[1,xst[2]]="Ref."
      
      # Number of observations
      dtmp.n=dtmp[!is.na(dtmp[,paste0(ovar,".0")])&!is.na(dtmp[,paste0(ovar,".6")]),]
      nvec=table(dtmp.n$rand)
      lm.body[1:4,3]=nvec
      lm.body[5:6,3]=nvec[2:3]+nvec[4]
      lm.body[7,3]="-"

      # N/ICC
      fmla=as.formula(paste0(ovar,".6 ~ unit"))
      saov=summary(aov(fmla, data = dtmp))
      sicc=saov[[1]][1,2]/sum(saov[[1]][,2])
      lm.head[2,1]=paste0("N=",sum(nvec),", ICC=",round(sicc,3))
                          
      # Marginal means
      lm.body[1:7,xst[1]+c(0,1)]="-"
      
      for(i2 in 1:4){
        lm.body[i2,xst[1]]=paste0(round(mci$emmean[i2],1)," (",round(mci$lower.CL[i2],1),", ",round(mci$upper.CL[i2],1),")")
      }
      for(i2 in 2:4){
        dm=mci$emmean[i2]-mci$emmean[1]
        cim=dm+(mci$SE[1]+mci$SE[i2])*1.96/2*c(-1,1)
        lm.body[i2,xst[1]+1]=paste0(round(dm,1)," (",round(cim[1],1),", ",round(cim[2],1),")")
      }

      # RCS and RCS+GMT
      m=(nvec[2]*mci$emmean[2]+nvec[4]*mci$emmean[4])/(nvec[2]+nvec[4])
      se=(sqrt(nvec[2])*mci$SE[2]+sqrt(nvec[4])*mci$SE[4])/sqrt(nvec[2]+nvec[4])
      cim=m+1.96*se*c(-1,1)
      lm.body[5,xst[1]]=paste0(round(m,1)," (",round(cim[1],1),", ",round(cim[1],1),")")
      # GMT and RCS+GMT
      m=(nvec[3]*mci$emmean[3]+nvec[4]*mci$emmean[4])/(nvec[3]+nvec[4])
      se=(sqrt(nvec[3])*mci$SE[3]+sqrt(nvec[4])*mci$SE[4])/sqrt(nvec[3]+nvec[4])
      cim=m+1.96*se*c(-1,1)
      lm.body[6,xst[1]]=paste0(round(m,1)," (",round(cim[1],1),", ",round(cim[1],1),")")

      # Marginal mean differnces
      se=(sqrt(nvec[1])*mci$SE[1]
          +sqrt(nvec[2])*mci$SE[2]
          +sqrt(nvec[3])*mci$SE[3]
          +sqrt(nvec[4])*mci$SE[4])/sqrt(nvec[1]+nvec[2]+nvec[3]+nvec[4])
      # RCS
      md=(nvec[2]*mci$emmean[2]+nvec[4]*mci$emmean[4])/(nvec[2]+nvec[4])-(nvec[1]*mci$emmean[1]+nvec[3]*mci$emmean[3])/(nvec[1]+nvec[3])
      cim=md+1.96*se*c(-1,1)
      lm.body[5,xst[1]+1]=paste0(round(md,1)," (",round(cim[1],1),", ",round(cim[2],1),")")
      # GMT
      md=(nvec[3]*mci$emmean[3]+nvec[4]*mci$emmean[4])/(nvec[3]+nvec[4])-(nvec[1]*mci$emmean[1]+nvec[2]*mci$emmean[2])/(nvec[1]+nvec[2])
      cim=md+1.96*se*c(-1,1)
      lm.body[6,xst[1]+1]=paste0(round(md,1)," (",round(cim[1],1),", ",round(cim[2],1),")")
    }
      # Merge tables
      tab.lm0=rbind(lm.head,lm.body)
      tab.lm0=tab.lm0[,-2]
      tab.lm=rbind(tab.lm,NA,tab.lm0)
      tab.lm.list[[cnames[j]]]=tab.lm
    }else{
      writeLines("  No data found")
    }
  }
  writeLines('********************************************************')
  
  if(test.xpt){
    writeLines("  Exporting table...")
    if(test.ppa){
      fname=paste0("./results/ancova/tab_ancova_ppa_",cnames[j],"_",fdate,".csv")
    }else{
      fname=paste0("./results/ancova/tab_ancova_itt_",cnames[j],"_",fdate,".csv")
    }
    writeLines(paste0("    Exporting to ",fname))
    write.table(tab.lm,file = fname,
                row.names = F, col.names = F, sep = ";", na = "")
  }
  writeLines('********************************************************')
}
