writeLines('********************************************************')
writeLines("ANCOVA MADRS")
lm.madrs = lme(madrs.6 ~ rand.rcs*rand.gmt + madrs.0,
               random = ~1|rv,
               na.action="na.omit",
               data=df.resident.wide,
               method = "REML")
print(summary(lm.madrs))
writeLines('--------------------------------------------------------')
writeLines("Confidence intervals")
ci=intervals(lm.madrs, which = "fixed")[[1]]
print(ci)
writeLines('********************************************************')
