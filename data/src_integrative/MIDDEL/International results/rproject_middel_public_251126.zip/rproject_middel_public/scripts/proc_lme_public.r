tab.lme.list=list()
for(ic in 0:6){
  if(ic==0){
    country="All patients"
  }else{
    country=levels(df.resident.long$country)[ic]
  }
  itit=c(1,4,7,10,13,14)
  icat=c(2,3,5,6,8,9,11,12,15,16)
  icoeff=c(2,3,5,6,8,9,11,12,13,15,16)
  xst=c(3,9)
  
  tab.lme.head1=matrix(ncol = 14, nrow = 5)
  tab.lme.head1[1,xst[1]]="Primary outcome"
  tab.lme.head1[2,xst]=c("MADRS","SIB-8")
  tab.lme.head1[4,c(xst[1]+c(0,3),xst[2]+c(0,3))]=c("only 2-ways-time interaction","with 3-way interaction")
  tab.lme.head1[5,c(xst[1]+c(0,1,3,4),xst[2]+c(0,1,3,4))]=c("B (95%CI)","p-value")
  tab.lme.head1[1,1]=country
  if(test.ppa){
    tab.lme.head1[2,1]="PPA"
  }else{
    tab.lme.head1[2,1]="ITT"
  }
  
  tab.lme.head2=tab.lme.head1
  tab.lme.head2[1,xst[1]]=c("Neuropsychiatric Inventory (NPI)")
  tab.lme.head2[2,xst]=c("Symptom severity","Caregiver distress")

  tab.lme.head3=tab.lme.head1
  tab.lme.head3[1,xst[1]]=c("Quality of life")
  tab.lme.head3[2,xst]=c("EQ-VAS","QOL-AD")

  tab.lme.head4=tab.lme.head1
  tab.lme.head4[1,xst[1]]=c("Staff")
  tab.lme.head4[2,xst]=c("PCTB","")
  tab.lme.head4[,8:14]=NA
  
  tab.lme.body0=matrix(ncol = 14,nrow = 16)
  tab.lme.body0[itit,1]=c("Time effect"," Main effects","Interaction time*RCS","Interaction time*GMT","Interaction RCS*GMT","3-ways interactions")
  tab.lme.body0[icat,2]=c("3 months","6 months","RCS","GMT","3 months * RCS","6 months * RCS","3 months * GMT","6 months * GMT","3 months * RCS * GMT","6 months * RCS * GMT")
  
  #for(i in 1:(n.v-1)){
  i=1
  for(i in 1:(7-test.ppa)){
#  for(i in 1:4){
      if(i<7){
      dtmp=df.resident.long
    }else{
      dtmp=df.staff.long
    }
    if(ic==0){
      dtmp=dtmp
      country="All patients"
    }else{
      dtmp=dtmp[dtmp$country==levels(dtmp$country)[ic],]
      country=levels(dtmp$country)[ic]
    }
    if(i<7){
      if(test.ppa){
        dtmp=dtmp[dtmp$pp==levels(dtmp$pp)[1],]
      }
    }
    dtmp=dtmp[dtmp$time<12,]
    dtmp$fu=droplevels(dtmp$fu)
    ovar = ovars[i]
    ist=((i-1)%%2)+1
    if(ist==1){
      tab.lme.body1=tab.lme.body0
    }
    writeLines(paste0(ovar," - ",country))
    if(sum(!is.na(dtmp[dtmp$time==6,ovar]))>0){
      writeLines("  0-model")
      fmla = as.formula(paste0(ovar," ~ fu"))
      lm.0 = lme(fmla, random = ~1|rv, na.action="na.omit", data=dtmp, method = "ML");
      summary(lm.0)
      
      writeLines("  Model with 2-way time interactions")
      lm.3 = update(lm.0, .~. + fu*rand.rcs + fu*rand.gmt)
      (s=summary(lm.3))
      p=s$tTable[2:9,5]
      plot(lm.3)
      if(i<3){
        tab.lme.head1[3,xst[ist]]=paste0("N=",summary(lm.3)$dims$N)
      }
      if(i%in%c(3,4)){
        tab.lme.head2[3,xst[ist]]=paste0("N=",summary(lm.3)$dims$N)
      }
      if(i%in%c(5,6)){
        tab.lme.head3[3,xst[ist]]=paste0("N=",summary(lm.3)$dims$N)
      }
      if(i>6){
        tab.lme.head4[3,xst[ist]]=paste0("N=",summary(lm.3)$dims$N)
      }
      
      ci=intervals(lm.3, which = "fixed")$fixed
      for(i2 in 1:8){
        tab.lme.body1[icoeff[i2],xst[ist]]=paste0(round(ci[i2+1,2],1)," (",round(ci[i2+1,1],1),", ",round(ci[i2+1,3],1),")")
        if(p[i2]<0.0001){
          tab.lme.body1[icoeff[i2],xst[ist]+1]="<0.0001"
        }else{
          tab.lme.body1[icoeff[i2],xst[ist]+1]=round(p[i2],4)
        }
      }
      
      writeLines("  Model with 3-way interactions")
      if(!(((ic==6)&(i==7))|((ic==4)&(i==2))|((ic==4)&(i==3))|((ic==4)&(i==4))|((ic==4)&(i==5)))){
        lm.4 = update(lm.0, .~. * rand.rcs * rand.gmt)
        (s=summary(lm.4))
        # print(s$tTable)
        plot(lm.4)
        p=s$tTable[2:12,5]
        ci=intervals(lm.4, which = "fixed")$fixed
        for(i2 in 1:11){
          tab.lme.body1[icoeff[i2],xst[ist]+3]=paste0(round(ci[i2+1,2],1)," (",round(ci[i2+1,1],1),", ",round(ci[i2+1,3],1),")")
          if(p[i2]<0.0001){
            tab.lme.body1[icoeff[i2],xst[ist]+4]="<0.0001"
          }else{
            tab.lme.body1[icoeff[i2],xst[ist]+4]=round(p[i2],4)
          }
        }
      }else{
        writeLines("    No convergence")
        tab.lme.body1[1,xst[ist]+3]="No convergence"
      }
    }else{
      writeLines("  No data found")
      tab.lme.body1[1,xst[ist]+3]="No data"
    }
    if(i==2){
      tab.lme=rbind(tab.lme.head1,tab.lme.body1)
    }
    if(i==4){
      tab.lme=rbind(tab.lme," ",tab.lme.head2,tab.lme.body1)
    }
    if(i==6){
      tab.lme=rbind(tab.lme," ",tab.lme.head3,tab.lme.body1)
    }
    if(i==7){
      tab.lme=rbind(tab.lme," ",tab.lme.head4,tab.lme.body1)
    }
    writeLines("**********************************************")  
  }
  tab.lme.list[[cnames[ic+1]]]=tab.lme

  if(test.xpt){
    writeLines("  Exporting table...")
    if(test.ppa){
      fname=paste0("./results/lme/tab_lme_ppa_",cnames[ic+1],"_",fdate,".csv")
    }else{
      fname=paste0("./results/lme/tab_lme_itt_",cnames[ic+1],"_",fdate,".csv")
    }
    writeLines(paste0("    Exporting to ",fname))
    write.table(tab.lme,file = fname,
                row.names = F, col.names = F, sep = ";", na = "")
  }
  writeLines('********************************************************')
}
