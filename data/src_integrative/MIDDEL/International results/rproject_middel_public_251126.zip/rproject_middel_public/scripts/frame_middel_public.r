############################
# libraries
library(psych)
library(nlme)
library(emmeans)
library(effectsize)

############################
# options
fdate="251120" # Date of computatiion and result export
test.xpt = F   # Export tables (T=yes, F=no)
test.ppa = F   # PPA vs. ITT   (T=PPA, F=ITT)

############################
# data preparation
load("./data/data_public.rdata")

# df.resident.long - Resident data long format
# df.resident.wide - Resident data wide format
# df.staff.long    - Staff data long format
# df.staff.wide    - Staff data wide format
# ovars            - List of output variables
# cnames           - List of country shortnames for export

############################
# analyses

# ANCOVA MADRS simple
 source("./scripts/proc_ancova_madrs_simple_public.r")

# ANCOVA tables
 source("./scripts/proc_ancova_public.r")

# LME tables
 source("./scripts/proc_lme_public.r")

