 *********************************************
 Readme public scripts and data MIDDEL
 20/11/2025
 
 *********************************************
 Data: ./data/data_public.rdata
 Conent:
    - df.resident.long - Resident data long format
    - df.resident.wide - Resident data wide format
    - df.staff.long    - Staff data long format
    - df.staff.wide    - Staff data wide format
    - ovars            - List of output variables
    - cnames           - List of country shortnames for export

 *********************************************
 Computation
 
 - start rpr_pub.Rproj
 - open ./scripts/frame_middel_public.r
 - needed installed packages:
    * psych
    * nlme
    * emmeans
    * effectsize
 - set options
    * fdate: date of compputation and result export (used in the filenames of the exported table
    * test.xpt  Select ift you want to export tables
                Oops! Overwrites tables with the same date
    * test.ppa  Select per protocol analyses (PPA) or intention to treat (ITT)
 - run scripts
    * ./scripts/proc_ancova_madrs_simple_public.r
        + runs ANCOVA for MADRS for all participants (ITT)
        + reports estimates with confidence intervals
    * ./scripts/proc_ancova_public.r
        + runs ANCOVA for all outcomes and countries
        + creates result tables
        + result tables stored in tab.lm.list
        + View tables after running:
            - View(tab.lm.list[["all"]]     all countries
            - View(tab.lm.list[["aus"]]     Australia    
            - View(tab.lm.list[["ger"]]     Grmany
            - View(tab.lm.list[["ned"]]     the Netherlands
            - View(tab.lm.list[["nor"]]     Norway
            - View(tab.lm.list[["tur"]]     Türkiye
            - View(tab.lm.list[["gbr"]]     Great Britain
        + exports unformatted result tables if test.xpt==T
    * ./scripts/proc_lme_public.r
        + runs LME for all outcomes and countries
        + creates result tables
        + result tables stored in tab.lme.list
        + View tables after running:
            - View(tab.lme.list[["all"]]     all countries
            - View(tab.lme.list[["aus"]]     Australia    
            - View(tab.lme.list[["ger"]]     Grmany
            - View(tab.lme.list[["ned"]]     the Netherlands
            - View(tab.lme.list[["nor"]]     Norway
            - View(tab.lme.list[["tur"]]     Türkiye
            - View(tab.lme.list[["gbr"]]     Great Britain
        + exports unformatted result tables if test.xpt==T
    
 *********************************************
 Results
 
 - exported tables are stored in ./results/lme or ./results/ancova
 - ./results/251120 contains all exported tables computed 20/11/2025
 
 
